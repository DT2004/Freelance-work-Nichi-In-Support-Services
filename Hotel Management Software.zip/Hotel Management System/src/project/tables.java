/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author Devansh
 */
public class tables {
    public static void main(String[] args)
    {
        Connection con=null;
        Statement st=null;
        
        try
        {
           
            con=MyConnection.getCon();
            Statement stmt=con.createStatement();
            String sql = "create table users(name varchar(200), email varchar(200) primary key, password varchar(50), securityQuestion varchar(500), answer varchar(200), status varchar(200))";
            //stmt.executeUpdate(sql);
            String ror= "create table room(roomNo varchar(10) primary key, roomType varchar(200), bed varchar(200), price int, status varchar(200))";
           String rer="create table customer(id int primary key, name varchar(200), mobileNumber varchar(20), nationality varchar (200), gender varchar(50), email varchar(200), idProof varchar(200),adress varchar(500, checkIn varchar(50), roomNo varchar(10), bed varchar(200), roomType varchar(200), pricePerDay int(10), numberOfDaysStay int(10), totalAmount varchar(200), checkout varchar(50), birthday varchar(50))";
            //stmt.executeUpdate(ror);//
            stmt.executeUpdate(rer);
           JOptionPane.showMessageDialog(null, "Table created successfully");
            
            con.close();
    }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        finally
        {
            try
            {
                con.close();
                st.close();
            }
            catch(Exception e){
                
            }
        }
       
       }
    }


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

/**
 *
 * @author Devansh
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class MyConnection {
    public static Connection getCon()
    {
        Connection con = null;
        try
        {
            //Class.forName("con.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel","root","amitisgreat");
            System.out.println("In Try");
        return con;
        }
        catch(SQLException e)
        {
            System.out.println(e);
            System.out.println("In catch");
            return null;
        }
    }
       public static void main(String[] args){
       
       String conn_value = getCon().toString();
       System.out.println(conn_value);
       // JOptionPane.showMessageDialog(null, "connection succesful");
       
       }    
}
